"""Report building and rendering (JSON + human-readable text).

Output is deterministic: stable ordering, sorted JSON keys and no timestamps.
"""

from __future__ import annotations

import json
from typing import Any, Dict, List

from devdiag import __version__
from devdiag.checks import FAIL, PASS, WARN, CheckResult

EXIT_OK = 0
EXIT_FAILED = 1
EXIT_USAGE = 2
EXIT_CONFIG = 3


def build_report(results: List[CheckResult]) -> Dict[str, Any]:
    summary = {
        "total": len(results),
        "passed": sum(r.status == PASS for r in results),
        "warnings": sum(r.status == WARN for r in results),
        "failed": sum(r.status == FAIL for r in results),
    }
    if summary["failed"]:
        overall = "unhealthy"
    elif summary["warnings"]:
        overall = "degraded"
    else:
        overall = "healthy"
    return {
        "tool": "devdiag",
        "version": __version__,
        "overall": overall,
        "summary": summary,
        "checks": [r.to_dict() for r in results],
    }


def exit_code(report: Dict[str, Any], strict: bool = False) -> int:
    if report["summary"]["failed"]:
        return EXIT_FAILED
    if strict and report["summary"]["warnings"]:
        return EXIT_FAILED
    return EXIT_OK


def render_json(report: Dict[str, Any]) -> str:
    return json.dumps(report, indent=2, sort_keys=True)


_MARK = {PASS: "[ OK ]", WARN: "[WARN]", FAIL: "[FAIL]"}


def render_text(report: Dict[str, Any]) -> str:
    s = report["summary"]
    lines = [f"devdiag {report['version']} - developer environment report", "=" * 54]
    for c in report["checks"]:
        lines.append(f"{_MARK[c['status']]} {c['name']:<18} {c['message']}")
    lines.append("-" * 54)
    lines.append(
        f"Overall: {report['overall'].upper()}  "
        f"({s['passed']} passed, {s['warnings']} warnings, {s['failed']} failed)"
    )
    return "\n".join(lines)
