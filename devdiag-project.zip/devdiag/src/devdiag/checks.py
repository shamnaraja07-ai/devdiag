"""Individual environment checks.

Every check returns a CheckResult with status "pass", "warn" or "fail".
System access goes through the Probe class so tests can substitute it.
"""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from devdiag.config import Config, parse_version

PASS, WARN, FAIL = "pass", "warn", "fail"


@dataclass
class CheckResult:
    name: str
    status: str
    message: str
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "status": self.status,
            "message": self.message,
            "details": self.details,
        }


class Probe:
    """Thin wrapper around system calls (replaceable in tests)."""

    def python_version(self) -> tuple:
        return tuple(sys.version_info[:3])

    def disk_usage(self, path: str):
        return shutil.disk_usage(path)

    def environ(self) -> Dict[str, str]:
        return dict(os.environ)

    def which(self, tool: str) -> Optional[str]:
        return shutil.which(tool)

    def tool_version(self, path: str) -> Optional[str]:
        try:
            proc = subprocess.run(
                [path, "--version"],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
        except (OSError, subprocess.SubprocessError):
            return None
        out = (proc.stdout or proc.stderr or "").strip()
        return out.splitlines()[0] if out else None


def check_python(cfg: Config, probe: Probe) -> CheckResult:
    actual = probe.python_version()
    needed = parse_version(cfg.min_python)
    text = ".".join(str(p) for p in actual)
    details = {"version": text, "minimum": cfg.min_python}
    if actual >= needed:
        return CheckResult("python", PASS, f"Python {text} (>= {cfg.min_python})", details)
    return CheckResult("python", FAIL, f"Python {text} is older than required {cfg.min_python}", details)


def check_disk(cfg: Config, probe: Probe) -> CheckResult:
    try:
        usage = probe.disk_usage(cfg.disk_path)
    except OSError as exc:
        return CheckResult(
            "disk_space",
            FAIL,
            f"cannot inspect disk at {cfg.disk_path}: {exc.strerror or exc}",
            {"path": cfg.disk_path},
        )
    gb = 1024 ** 3
    free_gb = round(usage.free / gb, 2)
    details = {
        "path": cfg.disk_path,
        "total_gb": round(usage.total / gb, 2),
        "free_gb": free_gb,
        "minimum_free_gb": cfg.min_free_gb,
    }
    if free_gb >= cfg.min_free_gb:
        return CheckResult("disk_space", PASS, f"{free_gb} GB free (>= {cfg.min_free_gb} GB)", details)
    return CheckResult("disk_space", FAIL, f"only {free_gb} GB free, need {cfg.min_free_gb} GB", details)


def check_env(cfg: Config, probe: Probe) -> List[CheckResult]:
    env = probe.environ()
    results = []
    for name in sorted(cfg.required_env):
        present = bool(env.get(name))
        results.append(
            CheckResult(
                f"env:{name}",
                PASS if present else FAIL,
                f"{name} is set" if present else f"required variable {name} is not set",
                {"required": True, "set": present},
            )
        )
    for name in sorted(cfg.optional_env):
        present = bool(env.get(name))
        results.append(
            CheckResult(
                f"env:{name}",
                PASS if present else WARN,
                f"{name} is set" if present else f"optional variable {name} is not set",
                {"required": False, "set": present},
            )
        )
    return results


def check_tools(cfg: Config, probe: Probe) -> List[CheckResult]:
    results = []
    for required, names in ((True, cfg.required_tools), (False, cfg.optional_tools)):
        for tool in sorted(names):
            path = probe.which(tool)
            if path is None:
                results.append(
                    CheckResult(
                        f"tool:{tool}",
                        FAIL if required else WARN,
                        f"{'required' if required else 'optional'} tool '{tool}' not found on PATH",
                        {"required": required, "found": False},
                    )
                )
                continue
            version = probe.tool_version(path)
            results.append(
                CheckResult(
                    f"tool:{tool}",
                    PASS,
                    f"{tool} found" + (f" ({version})" if version else ""),
                    {"required": required, "found": True, "path": path, "version": version},
                )
            )
    return results


def run_all(cfg: Config, probe: Optional[Probe] = None) -> List[CheckResult]:
    probe = probe or Probe()
    results: List[CheckResult] = [check_python(cfg, probe), check_disk(cfg, probe)]
    results += check_env(cfg, probe)
    results += check_tools(cfg, probe)
    return results
