"""Configuration loading and validation.

Config is a JSON object. All keys are optional; defaults are used otherwise.
Malformed or invalid configuration raises ConfigError (CLI exit code 3).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional


class ConfigError(Exception):
    """Raised when the configuration file is missing, malformed or invalid."""


@dataclass
class Config:
    min_python: str = "3.9"
    disk_path: str = "."
    min_free_gb: float = 1.0
    required_env: List[str] = field(default_factory=list)
    optional_env: List[str] = field(default_factory=lambda: ["VIRTUAL_ENV"])
    required_tools: List[str] = field(default_factory=lambda: ["git"])
    optional_tools: List[str] = field(default_factory=lambda: ["pip", "node", "docker"])


_KNOWN = {f for f in Config.__dataclass_fields__}


def _str_list(data: Dict[str, Any], key: str) -> Optional[List[str]]:
    if key not in data:
        return None
    value = data[key]
    if not isinstance(value, list) or not all(isinstance(v, str) and v for v in value):
        raise ConfigError(f"'{key}' must be a list of non-empty strings")
    return list(value)


def parse_version(text: str) -> tuple:
    try:
        parts = tuple(int(p) for p in text.split("."))
    except (ValueError, AttributeError):
        raise ConfigError(f"invalid version string: {text!r}") from None
    if not parts:
        raise ConfigError(f"invalid version string: {text!r}")
    return parts


def from_dict(data: Any) -> Config:
    if not isinstance(data, dict):
        raise ConfigError("configuration root must be a JSON object")
    unknown = sorted(set(data) - _KNOWN)
    if unknown:
        raise ConfigError(f"unknown configuration key(s): {', '.join(unknown)}")

    cfg = Config()
    if "min_python" in data:
        if not isinstance(data["min_python"], str):
            raise ConfigError("'min_python' must be a string like \"3.9\"")
        parse_version(data["min_python"])
        cfg.min_python = data["min_python"]
    if "disk_path" in data:
        if not isinstance(data["disk_path"], str) or not data["disk_path"]:
            raise ConfigError("'disk_path' must be a non-empty string")
        cfg.disk_path = data["disk_path"]
    if "min_free_gb" in data:
        v = data["min_free_gb"]
        if isinstance(v, bool) or not isinstance(v, (int, float)) or v < 0:
            raise ConfigError("'min_free_gb' must be a non-negative number")
        cfg.min_free_gb = float(v)
    for key in ("required_env", "optional_env", "required_tools", "optional_tools"):
        value = _str_list(data, key)
        if value is not None:
            setattr(cfg, key, value)
    return cfg


def load(path: Optional[str]) -> Config:
    if path is None:
        return Config()
    p = Path(path)
    try:
        text = p.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigError(f"cannot read config file {path}: {exc.strerror or exc}") from exc
    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ConfigError(f"malformed JSON in {path}: {exc.msg} (line {exc.lineno}, column {exc.colno})") from exc
    return from_dict(data)
