"""Command-line interface."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import List, Optional

from devdiag import __version__
from devdiag import checks, config, report


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="devdiag",
        description="Inspect this machine and print a developer-environment health report.",
        epilog="Exit codes: 0 healthy, 1 failed checks (or warnings with --strict), "
        "2 usage error, 3 configuration error.",
    )
    p.add_argument("-c", "--config", metavar="FILE", help="path to a JSON configuration file")
    p.add_argument(
        "-f", "--format", choices=["text", "json", "both"], default="text",
        help="output format (default: text)",
    )
    p.add_argument("-o", "--output", metavar="FILE", help="also write the JSON report to FILE")
    p.add_argument("--strict", action="store_true", help="treat warnings as failures (exit code 1)")
    p.add_argument("--version", action="version", version=f"devdiag {__version__}")
    return p


def main(argv: Optional[List[str]] = None, probe: Optional[checks.Probe] = None) -> int:
    args = build_parser().parse_args(argv)

    try:
        cfg = config.load(args.config)
    except config.ConfigError as exc:
        print(f"devdiag: configuration error: {exc}", file=sys.stderr)
        return report.EXIT_CONFIG

    rep = report.build_report(checks.run_all(cfg, probe))

    if args.output:
        try:
            Path(args.output).write_text(report.render_json(rep) + "\n", encoding="utf-8")
        except OSError as exc:
            print(f"devdiag: cannot write {args.output}: {exc.strerror or exc}", file=sys.stderr)
            return report.EXIT_USAGE

    if args.format in ("text", "both"):
        print(report.render_text(rep))
    if args.format in ("json", "both"):
        if args.format == "both":
            print()
        print(report.render_json(rep))

    return report.exit_code(rep, strict=args.strict)


if __name__ == "__main__":
    sys.exit(main())
