import json
from collections import namedtuple

import pytest

from devdiag import checks, cli, config, report

Usage = namedtuple("Usage", "total used free")
GB = 1024 ** 3


class FakeProbe(checks.Probe):
    def __init__(self, py=(3, 12, 1), free_gb=50, env=None, tools=None):
        self._py, self._free, self._env = py, free_gb, env or {}
        self._tools = tools if tools is not None else {"git": "git version 2.45.0"}

    def python_version(self):
        return self._py

    def disk_usage(self, path):
        return Usage(100 * GB, 100 * GB - self._free * GB, self._free * GB)

    def environ(self):
        return self._env

    def which(self, tool):
        return f"/usr/bin/{tool}" if tool in self._tools else None

    def tool_version(self, path):
        return self._tools.get(path.rsplit("/", 1)[-1])


def write_cfg(tmp_path, text):
    p = tmp_path / "cfg.json"
    p.write_text(text)
    return str(p)


# ---------- success path ----------

def test_success_all_healthy(tmp_path, capsys):
    cfg = write_cfg(tmp_path, json.dumps({
        "required_env": ["HOME"], "optional_env": [],
        "required_tools": ["git"], "optional_tools": [],
    }))
    probe = FakeProbe(env={"HOME": "/home/x"})
    code = cli.main(["-c", cfg, "-f", "json"], probe=probe)
    out = json.loads(capsys.readouterr().out)
    assert code == 0
    assert out["overall"] == "healthy"
    assert out["summary"]["failed"] == 0
    assert {c["name"] for c in out["checks"]} >= {"python", "disk_space", "env:HOME", "tool:git"}


def test_output_is_deterministic(capsys):
    cli.main(["-f", "both"], probe=FakeProbe())
    first = capsys.readouterr().out
    cli.main(["-f", "both"], probe=FakeProbe())
    assert capsys.readouterr().out == first


def test_text_report_is_human_readable(capsys):
    cli.main([], probe=FakeProbe())
    out = capsys.readouterr().out
    assert "developer environment report" in out
    assert "Overall:" in out


def test_output_file_written(tmp_path):
    target = tmp_path / "r.json"
    cli.main(["-o", str(target)], probe=FakeProbe())
    assert json.loads(target.read_text())["tool"] == "devdiag"


# ---------- missing dependency path ----------

def test_missing_required_tool_fails(tmp_path, capsys):
    cfg = write_cfg(tmp_path, json.dumps({"required_tools": ["git", "cargo"], "optional_tools": []}))
    code = cli.main(["-c", cfg, "-f", "json"], probe=FakeProbe())
    out = json.loads(capsys.readouterr().out)
    cargo = next(c for c in out["checks"] if c["name"] == "tool:cargo")
    assert code == 1
    assert cargo["status"] == "fail"
    assert out["overall"] == "unhealthy"


def test_missing_optional_tool_only_warns(tmp_path, capsys):
    cfg = write_cfg(tmp_path, json.dumps({"required_tools": ["git"], "optional_tools": ["docker"]}))
    code = cli.main(["-c", cfg, "-f", "json"], probe=FakeProbe())
    out = json.loads(capsys.readouterr().out)
    assert code == 0
    assert out["overall"] == "degraded"


def test_strict_turns_warnings_into_failure(tmp_path):
    cfg = write_cfg(tmp_path, json.dumps({"required_tools": [], "optional_tools": ["docker"]}))
    assert cli.main(["-c", cfg, "--strict"], probe=FakeProbe()) == 1


def test_missing_required_env_var_fails(tmp_path):
    cfg = write_cfg(tmp_path, json.dumps({"required_env": ["API_KEY"], "required_tools": []}))
    assert cli.main(["-c", cfg], probe=FakeProbe(env={})) == 1


def test_old_python_fails():
    res = checks.check_python(config.Config(min_python="3.11"), FakeProbe(py=(3, 8, 0)))
    assert res.status == "fail"


def test_low_disk_fails():
    res = checks.check_disk(config.Config(min_free_gb=10), FakeProbe(free_gb=2))
    assert res.status == "fail"


# ---------- malformed configuration path ----------

@pytest.mark.parametrize("text", [
    "{ not json",
    "[]",
    '{"unknown_key": 1}',
    '{"min_python": 3.9}',
    '{"min_python": "three"}',
    '{"min_free_gb": -1}',
    '{"required_tools": "git"}',
    '{"required_env": [1, 2]}',
])
def test_malformed_config_exit_code_3(tmp_path, capsys, text):
    code = cli.main(["-c", write_cfg(tmp_path, text)], probe=FakeProbe())
    assert code == 3
    assert "configuration error" in capsys.readouterr().err


def test_missing_config_file_exit_code_3(tmp_path, capsys):
    assert cli.main(["-c", str(tmp_path / "nope.json")], probe=FakeProbe()) == 3


def test_config_load_defaults():
    assert config.load(None) == config.Config()


def test_usage_error_exit_code_2():
    with pytest.raises(SystemExit) as exc:
        cli.main(["--format", "xml"])
    assert exc.value.code == 2


def test_real_system_smoke(capsys):
    # No fake probe: make sure the real checks run without crashing.
    code = cli.main(["-f", "json"])
    assert code in (0, 1)
    assert json.loads(capsys.readouterr().out)["tool"] == "devdiag"
